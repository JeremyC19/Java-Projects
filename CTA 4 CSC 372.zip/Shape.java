
abstract public class Shape {
    abstract double surface_area();

    abstract double volume();
}

